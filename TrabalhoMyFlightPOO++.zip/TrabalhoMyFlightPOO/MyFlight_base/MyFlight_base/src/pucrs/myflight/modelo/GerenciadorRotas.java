package pucrs.myflight.modelo;

public class GerenciadorRotas extends Rota{

    public GerenciadorRotas(CiaAerea cia, Aeroporto origem, Aeroporto destino, Aeronave aeronave) {
        super(cia, origem, destino, aeronave);
    }

}
