package pucrs.myflight.modelo;

import java.time.Duration;
import java.time.LocalDateTime;

public class GerenciadorVoos extends Voo{

    public GerenciadorVoos(Rota rota, LocalDateTime datahora, Duration duracao) {
        super(rota, datahora, duracao);
    }

    @Override
    public Rota getRota() {
        throw new UnsupportedOperationException("Unimplemented method 'getRota'");
    }

    @Override
    public Duration getDuracao() {
        throw new UnsupportedOperationException("Unimplemented method 'getDuracao'");
    }

}
