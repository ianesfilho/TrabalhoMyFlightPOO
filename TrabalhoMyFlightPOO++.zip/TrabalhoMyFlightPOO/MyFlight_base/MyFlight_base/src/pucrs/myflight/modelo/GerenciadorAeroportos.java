package pucrs.myflight.modelo;

public class GerenciadorAeroportos extends Aeroporto{

    public GerenciadorAeroportos(String codigo, String nome, Geo loc) {
        super(codigo, nome, loc);
    }

}
