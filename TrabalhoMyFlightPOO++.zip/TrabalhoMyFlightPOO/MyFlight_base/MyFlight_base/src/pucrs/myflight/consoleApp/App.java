package pucrs.myflight.consoleApp;

import pucrs.myflight.modelo.VooEscalas;

public class App {

	public static void main(String[] args) {
		System.out.println("\nMyFlight project...");
	}
}
