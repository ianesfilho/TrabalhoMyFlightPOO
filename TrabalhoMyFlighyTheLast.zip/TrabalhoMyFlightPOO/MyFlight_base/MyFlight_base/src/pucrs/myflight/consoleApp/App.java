package pucrs.myflight.consoleApp;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import pucrs.myflight.modelo.Aeroporto;
import pucrs.myflight.modelo.CiaAerea;
import pucrs.myflight.modelo.Rota;
import pucrs.myflight.modelo.VooEscalas;
import pucrs.myflight.modelo.lerAeroporto;
import pucrs.myflight.modelo.lerCiaAerea;
import pucrs.myflight.modelo.lerRotas;

public class App {

	public static void main(String[] args) {
		System.out.println("\nMyFlight project...");

	List<CiaAerea> airlines = lerCiaAerea.readAirlines("airlines.dat");

        for (CiaAerea airline : airlines) {
            System.out.println("Codigo: " + airline.getCodigo());
            System.out.println("Nome: " + airline.getNome());
            System.out.println();
        }

	String filename = "airports.dat";
	List<Aeroporto> airports = lerAeroporto.readAirports(filename);

	// Exemplo de exibição dos aeroportos
	for (Aeroporto airport : airports) {
		System.out.println("Nome: " + airport.getNome());
		System.out.println("Código: " + airport.getCodigo());
		System.out.println("Local: " + airport.getLocal());
		System.out.println();
	}

	List<Rota> routes = lerRotas.readRoutes("routes.dat");

        for (Rota route : routes) {
			System.out.println("Cia: " + route.getCia());
            System.out.println("Origem: " + route.getOrigem());
            System.out.println("Destino: " + route.getDestino());
            System.out.println("Aeronave: " + route.getAeronave());
            System.out.println();
        }
}

}
