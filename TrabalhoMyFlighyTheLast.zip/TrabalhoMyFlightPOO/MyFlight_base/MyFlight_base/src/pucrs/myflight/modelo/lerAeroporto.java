package pucrs.myflight.modelo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class lerAeroporto {
    public static List<Aeroporto> readAirports(String filename) {
        List<Aeroporto> airports = new ArrayList<>();

        try {
            File file = new File(filename);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");

                Aeroporto airport = new Aeroporto();
                airport.setNome(parts[0]);
                airport.setCodigo(parts[1]);
                airport.setLoc(parts[2]);

                airports.add(airport);
            }

            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return airports;
    }
}
