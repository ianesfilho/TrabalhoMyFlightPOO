package pucrs.myflight.modelo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Aeroporto implements Contavel, Comparable<Aeroporto>, Serializable{
	private String codigo;
	private String nome;
	private String loc;
	
	public Aeroporto() {
		this.codigo = codigo;
		this.nome = nome;
		this.loc = loc;
	}
	
	public String getCodigo() {
		return codigo;
	}
	
	public String getNome() {
		return nome;
	}
	
	public String getLocal() {
		return loc;
	}

	public void qtdObjetos() {

	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	@Override
	public int compareTo(Aeroporto o) {
		throw new UnsupportedOperationException("Unimplemented method 'compareTo'");
	}

    public void add(Aeroporto airports) {
    }

}
