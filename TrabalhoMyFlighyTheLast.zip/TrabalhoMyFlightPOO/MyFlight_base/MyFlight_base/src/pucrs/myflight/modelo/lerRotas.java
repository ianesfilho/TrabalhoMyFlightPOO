package pucrs.myflight.modelo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class lerRotas {
    public static List<Rota> readRoutes(String filePath) {
        List<Rota> routes = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(","); 
                String cia = parts[0];
                String origem = parts[1];
                String destino = parts[2];
                String aeronave = parts[3];

                Rota route = new Rota(cia, origem, destino, aeronave);
                routes.add(route);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return routes;
    }
}