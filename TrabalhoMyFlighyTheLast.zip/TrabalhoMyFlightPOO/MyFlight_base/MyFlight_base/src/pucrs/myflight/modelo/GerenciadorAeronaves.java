package pucrs.myflight.modelo;

public class GerenciadorAeronaves extends Aeronave{

    public GerenciadorAeronaves(String codigo, String descricao) {
        super(codigo, descricao);
    }
    
}
