package pucrs.myflight.modelo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class lerCiaAerea {
    public static List<CiaAerea> readAirlines(String fileName) {
        List<CiaAerea> airlines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String code = parts[0];
                String name = parts[1];
                CiaAerea airline = new CiaAerea(code, name);
                airlines.add(airline);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return airlines;
    }
}

