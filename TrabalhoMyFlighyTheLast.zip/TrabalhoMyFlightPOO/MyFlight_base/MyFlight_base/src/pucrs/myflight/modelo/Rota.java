package pucrs.myflight.modelo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Rota implements Contavel, Comparable<CiaAerea>, Serializable{
	private CiaAerea cia;
	private String origem;
	private String destino;
	private String aeronave;
	
	public Rota(CiaAerea cia2, String origem2, String destino2, String aeronave2) {
		this.cia = cia;
		this.origem = origem2;
		this.destino = destino2;
		this.aeronave = aeronave2;		
	}	
	
	public Rota(CiaAerea cia2, Aeroporto origem2, Aeroporto destino2, Aeronave aeronave2) {
    }

    public CiaAerea getCia() {
		return cia;
	}
	
	public String getDestino() {
		return destino;
	}
	
	public String getOrigem() {
		return origem;
	}
	
	public String getAeronave() {
		return aeronave;
	}

	public void qtdObjetos() {

	}

	@Override
	public int compareTo(CiaAerea o) {
		throw new UnsupportedOperationException("Unimplemented method 'compareTo'");
	}

}
