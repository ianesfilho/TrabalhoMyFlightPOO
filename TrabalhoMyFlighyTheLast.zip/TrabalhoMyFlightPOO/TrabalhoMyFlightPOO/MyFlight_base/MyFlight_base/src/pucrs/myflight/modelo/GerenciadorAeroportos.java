package pucrs.myflight.modelo;

public class GerenciadorAeroportos {

}
