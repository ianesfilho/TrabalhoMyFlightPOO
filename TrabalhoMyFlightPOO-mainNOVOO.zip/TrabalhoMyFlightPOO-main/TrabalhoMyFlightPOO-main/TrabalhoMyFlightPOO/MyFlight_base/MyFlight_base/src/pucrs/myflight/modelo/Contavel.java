package pucrs.myflight.modelo;

    interface Contavel {
        void qtdObjetos();
    }

